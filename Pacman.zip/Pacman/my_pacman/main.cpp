#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include "Game.h"
#include <iostream>
bool shouldCloseWindow = false;

void handleEvents(sf::RenderWindow& window)
{
    sf::Event event;
    while (window.pollEvent(event))
    {
        //   
        if (event.type == sf::Event::Closed)
        {
            window.close();
        }
    }
}

void update(sf::Clock& clock, Game& game)
{
    const float elapsedTime = clock.getElapsedTime().asSeconds();
    clock.restart();
    game.updateGame(elapsedTime);
}

void render(sf::RenderWindow& window, const Game& game)
{
    window.clear();
    game.render(window);
    window.display();
}
void shouldCloseWindows(sf::RenderWindow& window, Game& game) {
    window.close();
}


int main()
{
    sf::RenderWindow window(sf::VideoMode(WINDOW_HEIGHT*CELL_SIZE, WINDOW_WIGHT*CELL_SIZE), "PacMan Game Clone", sf::Style::Close);
    sf::Clock clock;

    Game game;
    // Загрузка звукового файла
    sf::SoundBuffer soundBuffer4;
    sf::Sound sound4;
    sound4.setBuffer(soundBuffer4);
    sf::Event event;

    // Воспроизведение звуковой дорожки при открытии окна
    soundBuffer4.loadFromFile("Resources/sound/pacman_beginning.wav");
    sound4.setPitch(1.5f); // Увеличение на 50%
    sound4.setVolume(40);

    sound4.play();

    sf::SoundBuffer soundBuffer;
    sf::Sound sound;
    sound.setBuffer(soundBuffer);

    // Воспроизведение звуковой дорожки при открытии окна
    soundBuffer.loadFromFile("Resources/sound/poluchenie-bonusa.wav");
    sound.setPitch(1.5f); // Увеличение на 50%
    sound.setVolume(10);
    sound.setLoop(true);
    sound.play();




    while (window.isOpen())
    {
        handleEvents(window);
        update(clock, game);
        render(window, game);
    }

    sound.stop();



    return 0;
}