#pragma once
#include "Entity.h"
#include <random>

static const sf::Color GHOST_COLOR = sf::Color(200, 32, 200);
static const sf::Color GHOST_COLOR1 = sf::Color(100, 32, 200);
static const sf::Color GHOST_COLOR2 = sf::Color(200, 32, 100);
static const sf::Color GHOST_COLOR3 = sf::Color(200, 132, 200);
static const sf::Color GHOST_COLOR4 = sf::Color(200, 232, 200);
static const float GHOST_SPEED = 80.f; // pixels per second.
static const float GHOST_RADIUS = 9.f; // pixels

class Blinky : public MovingEntity {
private:
    bool isMoving;
public:
    Blinky(int xPos, int yPos) {
        isMoving = true;
        //direction = Direction::NONE;
        shape.setRadius(GHOST_RADIUS);
        shape.setFillColor(GHOST_COLOR1);
        shape.setPosition(sf::Vector2f(xPos, yPos));
        // Инициализация генератора случайных чисел

        // Диапазон случайных направлений
    }

    void stopMovingBlinky(float elapsedTime, std::vector<bool>& massiv1)
    {
        isMoving = false;
        const float step = GHOST_SPEED * elapsedTime;
        sf::Vector2f antimovement(0.f, 0.f);
        // Обработка остановки движения в зависимости от стороны столкновения

        if(massiv1[0]){
            antimovement.y += step;
        }
        if(massiv1[1]){
            antimovement.x -= step;
        }
        if(massiv1[2]){
            antimovement.y -= step;
        }
        if(massiv1[3]){
            antimovement.x += step;
        }

        shape.move(antimovement);
    }

    void updateBlinkyDirection(std::vector<bool>& massiv1) {
        isMoving = true;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && !massiv1[0])
        {
            direction = Direction::UP;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && !massiv1[2])
        {
            direction = Direction::DOWN;

        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && !massiv1[3])
        {
            direction = Direction::LEFT;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && !massiv1[1])
        {
            direction = Direction::RIGHT;
        }


    }


    void updateBlinky(float elapsedTime, std::vector<std::string> map, std::vector<bool>& massiv1) {
        const float step = GHOST_SPEED * elapsedTime;


        updateBlinkyDirection(massiv1);
        if (!isMoving) {
            return;
        }


        sf::Vector2f movement(0.f, 0.f);
        switch (direction) {
            case Direction::UP:
                movement.y -= step;
                break;
            case Direction::DOWN:
                movement.y += step;
                break;
            case Direction::LEFT:
                movement.x -= step;
                break;
            case Direction::RIGHT:
                movement.x += step;
                break;

        }

        shape.move(movement);

    }

};




class Clyde : public MovingEntity {
private:
    bool isMoving;
public:
    Clyde(int xPos, int yPos) {
        isMoving = true;
        //direction = Direction::NONE;
        shape.setRadius(GHOST_RADIUS);
        shape.setFillColor(GHOST_COLOR2);
        shape.setPosition(sf::Vector2f(xPos, yPos));
        // Инициализация генератора случайных чисел

        // Диапазон случайных направлений
    }

    void stopMovingClyde(float elapsedTime, std::vector<bool>& massiv2)
    {
        isMoving = false;
        const float step = GHOST_SPEED * elapsedTime;
        sf::Vector2f antimovement(0.f, 0.f);
        // Обработка остановки движения в зависимости от стороны столкновения

        if(massiv2[0]){
            antimovement.y += step;
            direction = Direction::LEFT;
        }
        if(massiv2[1]){
            antimovement.x -= step;
            direction = Direction::UP;

        }
        if(massiv2[2]){
            antimovement.y -= step;
            direction = Direction::RIGHT;
        }
        if(massiv2[3]){
            antimovement.x += step;
            direction = Direction::DOWN;
        }

        shape.move(antimovement);
    }

    void updateClydeDirection(std::vector<bool>& massiv2) {
        isMoving = true;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::T) && !massiv2[0])
        {
            direction = Direction::UP;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::G) && !massiv2[2])
        {
            direction = Direction::DOWN;

        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::F) && !massiv2[3])
        {
            direction = Direction::LEFT;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::H) && !massiv2[1])
        {
            direction = Direction::RIGHT;
        }


    }


    void updateClyde(float elapsedTime, std::vector<std::string> map, std::vector<bool>& massiv2) {
        const float step = GHOST_SPEED * elapsedTime;


        updateClydeDirection(massiv2);
        if (!isMoving) {
            return;
        }


        sf::Vector2f movement(0.f, 0.f);
        switch (direction) {
            case Direction::UP:
                movement.y -= step;
                break;
            case Direction::DOWN:
                movement.y += step;
                break;
            case Direction::LEFT:
                movement.x -= step;
                break;
            case Direction::RIGHT:
                movement.x += step;
                break;

        }

        shape.move(movement);

    }

};


class Inky : public MovingEntity {
private:
    bool isMoving;
public:
    Inky(int xPos, int yPos) {
        isMoving = true;
        //direction = Direction::NONE;
        shape.setRadius(GHOST_RADIUS);
        shape.setFillColor(GHOST_COLOR3);
        shape.setPosition(sf::Vector2f(xPos, yPos));
        // Инициализация генератора случайных чисел

        // Диапазон случайных направлений
    }

    void stopMovingInky(float elapsedTime, std::vector<bool>& massiv3)
    {
        isMoving = false;
        const float step = GHOST_SPEED * elapsedTime;
        sf::Vector2f antimovement(0.f, 0.f);
        // Обработка остановки движения в зависимости от стороны столкновения

        if(massiv3[0]){
            antimovement.y += step;
            direction = Direction::LEFT;
        }
        if(massiv3[1]){
            antimovement.x -= step;
            direction = Direction::UP;

        }
        if(massiv3[2]){
            antimovement.y -= step;
            direction = Direction::RIGHT;
        }
        if(massiv3[3]){
            antimovement.x += step;
            direction = Direction::DOWN;
        }

        shape.move(antimovement);
    }

    void updateInkyDirection(std::vector<bool>& massiv3) {
        isMoving = true;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::T) && !massiv3[0])
        {
            direction = Direction::UP;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::G) && !massiv3[2])
        {
            direction = Direction::DOWN;

        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::F) && !massiv3[3])
        {
            direction = Direction::LEFT;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::H) && !massiv3[1])
        {
            direction = Direction::RIGHT;
        }


    }


    void updateInky(float elapsedTime, std::vector<std::string> map, std::vector<bool>& massiv3) {
        const float step = GHOST_SPEED * elapsedTime;


        updateInkyDirection(massiv3);
        if (!isMoving) {
            return;
        }


        sf::Vector2f movement(0.f, 0.f);
        switch (direction) {
            case Direction::UP:
                movement.y -= step;
                break;
            case Direction::DOWN:
                movement.y += step;
                break;
            case Direction::LEFT:
                movement.x -= step;
                break;
            case Direction::RIGHT:
                movement.x += step;
                break;

        }

        shape.move(movement);

    }

};



class Pinky : public MovingEntity {
private:
    bool isMoving;
public:
    Pinky(int xPos, int yPos) {
        isMoving = true;
        //direction = Direction::NONE;
        shape.setRadius(GHOST_RADIUS);
        shape.setFillColor(GHOST_COLOR4);
        shape.setPosition(sf::Vector2f(xPos, yPos));
        // Инициализация генератора случайных чисел

        // Диапазон случайных направлений
    }

    void stopMovingPinky(float elapsedTime, std::vector<bool>& massiv4)
    {
        isMoving = false;
        const float step = GHOST_SPEED * elapsedTime;
        sf::Vector2f antimovement(0.f, 0.f);
        // Обработка остановки движения в зависимости от стороны столкновения

        if(massiv4[0]){
            antimovement.y += step;
            direction = Direction::LEFT;
        }
        if(massiv4[1]){
            antimovement.x -= step;
            direction = Direction::UP;

        }
        if(massiv4[2]){
            antimovement.y -= step;
            direction = Direction::RIGHT;
        }
        if(massiv4[3]){
            antimovement.x += step;
            direction = Direction::DOWN;
        }

        shape.move(antimovement);
    }

    void updatePinkyDirection(std::vector<bool>& massiv4) {
        isMoving = true;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::T) && !massiv4[0])
        {
            direction = Direction::UP;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::G) && !massiv4[2])
        {
            direction = Direction::DOWN;

        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::F) && !massiv4[3])
        {
            direction = Direction::LEFT;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::H) && !massiv4[1])
        {
            direction = Direction::RIGHT;
        }


    }


    void updatePinky(float elapsedTime, std::vector<std::string> map, std::vector<bool>& massiv4) {
        const float step = GHOST_SPEED * elapsedTime;


        updatePinkyDirection(massiv4);
        if (!isMoving) {
            return;
        }


        sf::Vector2f movement(0.f, 0.f);
        switch (direction) {
            case Direction::UP:
                movement.y -= step;
                break;
            case Direction::DOWN:
                movement.y += step;
                break;
            case Direction::LEFT:
                movement.x -= step;
                break;
            case Direction::RIGHT:
                movement.x += step;
                break;

        }

        shape.move(movement);

    }

};


















