#include "Game.h"
#include <fstream>
#include <iostream>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
sf::SoundBuffer soundBuffer1;
sf::Sound sound1;
// Функция для чтения карты из файла
std::vector<std::string> readMapFromFile(const std::string& filename)
{
    std::vector<std::string> map;
    std::ifstream file(filename);



    if (file.is_open())
    {
        std::string line;
        while (std::getline(file, line))
        {
            map.push_back(line);
        }
        file.close();
    }


    return map;
}


Game::Game()
{
    width = 0;
    height = 0;
    int pacmanX = 110;
    int pacmanY = 110;
    int BlinkyX = 360;
    int BlinkyY = 20;
    int ClydeX = 360;
    int ClydeY = 380;
    int InkyX = 40;
    int InkyY = 20;
    int PinkyX = 40;
    int PinkyY = 380;
    soundBuffer1.loadFromFile("Resources/sound/poluchenie-bonusa.wav");

    pacman = new Pacman(pacmanX, pacmanY);
    blinky = new Blinky(BlinkyX, BlinkyY);
    clyde = new Clyde(ClydeX, ClydeY);
    inky = new Inky(InkyX, InkyY);
    pinky = new Pinky(PinkyX, PinkyY);
    // Чтение карты из файла
    map = readMapFromFile("Resources/map.txt");

    // Создание статической карты
    for (int i = 0; i < map.size(); i++)
    {
        for (int j = 0; j < map[i].size(); j++)
        {
            if (map[i][j] == '#')
            {
                int x = j * CELL_SIZE;
                int y = i * CELL_SIZE;
                cells.push_back(new Cell(x, y, CELL_SIZE));
                //objects.push_back(cells.back());  // Добавление вектора cells в objects
            }
            if (map[i][j] == '.') // Если символ равен ".", это точка
            {
                // Создаем объект точки с заданными параметрами
                int x1 = j * CELL_SIZE + CELL_SIZE / 2;
                int y1 = i * CELL_SIZE + CELL_SIZE / 2;
                PacGum* pacGum = new PacGum(x1, y1, PacGum_SIZE);
                // Добавляем точку в вектор
                points.push_back(pacGum);
                //objects.push_back(pacGum);  // Добавление pacGum в objects
            }
            if (map[i][j] == 'o') // Если символ равен ".", это точка
            {
                // Создаем объект точки с заданными параметрами
                int x1 = j * CELL_SIZE + CELL_SIZE / 2;
                int y1 = i * CELL_SIZE + CELL_SIZE / 2;
                SuperPacGum* superPacGum = new SuperPacGum(x1, y1, SuperPacGum_SIZE);
                // Добавляем точку в вектор
                super_points.push_back(superPacGum);
                //objects.push_back(superPacGum);  // Добавление superPacGum в objects
            }
        }
        //objects.insert(objects.end(), cells.begin(), cells.end());
    }

    // Добавьте другие инициализации объектов, если необходимо
}

std::vector<Entity*> Game::getEntities()
{
    return objects;
}

std::vector<Cell*> Game::getCells()
{
    return cells;
}

Pacman* Game::getPacman()
{
    return pacman;
}
Blinky* Game::getBlinky()
{
    return blinky;
}
Clyde* Game::getClyde()
{
    return clyde;
}
Inky* Game::getInky()
{
    return inky;
}
/*Pinky* Game::getPinky()
{
    return pinky;
}*/
void Game::updateGame(float elapsedTime)
{

    std::vector<bool> massiv(4, false);
    std::vector<bool> massiv1(4, false);
    std::vector<bool> massiv2(4, false);
    std::vector<bool> massiv3(4, false);
    std::vector<bool> massiv4(4, false);
    checkCollisions(elapsedTime, massiv, massiv1, massiv2, massiv3, massiv4);
    pacman->update(elapsedTime, map, massiv);
    blinky->updateBlinky(elapsedTime, map, massiv1);
    clyde->updateClyde(elapsedTime, map, massiv2);
    inky->updateInky(elapsedTime, map, massiv3);
    pinky->updatePinky(elapsedTime, map, massiv4);
    // Удаление PacGum при столкновении с Pacman
    for (auto it = points.begin(); it != points.end(); )
    {
        PacGum* pacGum = *it;

        sf::FloatRect pacmanBounds = pacman->getBounds();
        sf::CircleShape pacGumShape(pacGum->getsize() / 2.0f);
        pacGumShape.setPosition(sf::Vector2f(pacGum->getpos().x, pacGum->getpos().y));
        sf::FloatRect pacGumBounds = pacGumShape.getGlobalBounds();

        // Увеличение границ жвачки
        float expandedBounds = 1.5f; // Множитель для увеличения границ
        sf::FloatRect expandedPacGumBounds(
                pacGumBounds.left - (pacGumBounds.width * expandedBounds),
                pacGumBounds.top - (pacGumBounds.height * expandedBounds),
                pacGumBounds.width * (1 + expandedBounds),
                pacGumBounds.height * (1 + expandedBounds)
        );

        if (expandedPacGumBounds.contains(pacmanBounds.left + pacmanBounds.width / 2.0f, pacmanBounds.top + pacmanBounds.height / 2.0f))
        {
            it = points.erase(it);


            // Воспроизведение звуковой дорожки при открытии окна

            // objects.erase(std::find(objects.begin(), objects.end(), pacGum));
            delete pacGum;
            // Увеличение счета игры
            score += 10;
            std::cout << "\n" << score;
        }
        else
        {
            ++it;
        }
    }


    for (auto it = super_points.begin(); it != super_points.end(); )
    {
        SuperPacGum* superPacGum = *it;
        sf::FloatRect pacmanBounds = pacman->getBounds();
        sf::CircleShape pacGumShape(superPacGum->getsize1() / 2.0f);
        pacGumShape.setPosition(sf::Vector2f(superPacGum->getpos1().x, superPacGum->getpos1().y));
        sf::FloatRect pacGumBounds = pacGumShape.getGlobalBounds();

        // Увеличение границ супержвачки
        float expandedBounds = 1.5f; // Множитель для увеличения границ
        sf::FloatRect expandedPacGumBounds(
                pacGumBounds.left - (pacGumBounds.width * expandedBounds),
                pacGumBounds.top - (pacGumBounds.height * expandedBounds),
                pacGumBounds.width * (1 + expandedBounds),
                pacGumBounds.height * (1 + expandedBounds)
        );

        if (expandedPacGumBounds.contains(pacmanBounds.left + pacmanBounds.width  / 2.0f, pacmanBounds.top + pacmanBounds.height  / 2.0f))
        {
            it = super_points.erase(it);
            sound1.setBuffer(soundBuffer1);
            sound1.setPitch(1.5f);
            sound1.play();
            isSuperPacman = true;
            delete superPacGum;

            // Увеличение счета игры
            score += 100;
            std::cout << "\n" << score;
        }
        else
        {
            ++it;
        }
    }



    // Обновите другие объекты, если необходимо
}


void Game::checkCollisions(float elapsedTime, std::vector<bool>& massiv, std::vector<bool>& massiv1, std::vector<bool>& massiv2, std::vector<bool>& massiv3, std::vector<bool>& massiv4) {
    sf::FloatRect pacmanBounds = pacman->getBounds();

    for (auto cell: cells) {
        sf::FloatRect cellBounds = cell->getBounds();
        sf::Vector2f pacmanCenter = sf::Vector2f(pacmanBounds.left, pacmanBounds.top) +
                                    0.5f * sf::Vector2f(pacmanBounds.width, pacmanBounds.height);
        sf::Vector2f cellCenter = sf::Vector2f(cellBounds.left, cellBounds.top) +
                                  0.5f * sf::Vector2f(cellBounds.width, cellBounds.height);

        sf::Vector2f delta = pacmanCenter - cellCenter;

        float deltaX = delta.x;
        float deltaY = delta.y;

        //CollisionSide collisionSide = CollisionSide::None;
        if (std::abs(deltaX) < 18 && std::abs(deltaY) < 18) {
            if (std::abs(deltaX) > std::abs(deltaY)) {//std::abs(deltaY)
                if (deltaX > 0) {
                    //collisionSide = CollisionSide::Left;
                    massiv[3] = true;

                } else {
                    //collisionSide = CollisionSide::Right;
                    massiv[1] = true;
                }
            } else if (std::abs(deltaX) < std::abs(deltaY)) {
                if (deltaY > 0) {
                    //collisionSide = CollisionSide::Top;
                    massiv[0] = true;
                } else {
                    //collisionSide = CollisionSide::Bottom;
                    massiv[2] = true;
                }
            }
        }

    }
    pacman->stopMoving(elapsedTime, massiv);

    sf::FloatRect blinkyBounds = blinky->getBounds();

    for (auto cell: cells) {
        sf::FloatRect cellBounds = cell->getBounds();
        sf::Vector2f blinkyCenter = sf::Vector2f(blinkyBounds.left, blinkyBounds.top) +
                                    0.5f * sf::Vector2f(blinkyBounds.width, blinkyBounds.height);
        sf::Vector2f cellCenter = sf::Vector2f(cellBounds.left, cellBounds.top) +
                                  0.5f * sf::Vector2f(cellBounds.width, cellBounds.height);

        sf::Vector2f delta = blinkyCenter - cellCenter;

        float deltaX = delta.x;
        float deltaY = delta.y;

        //CollisionSide collisionSide = CollisionSide::None;

        if (std::abs(deltaX) < 18 && std::abs(deltaY) < 18) {
            if (std::abs(deltaX) > std::abs(deltaY)) {//std::abs(deltaY)
                if (deltaX > 0) {
                    //collisionSide = CollisionSide::Left;
                    massiv1[3] = true;

                } else {
                    //collisionSide = CollisionSide::Right;
                    massiv1[1] = true;
                }
            } else if (std::abs(deltaX) < std::abs(deltaY)) {
                if (deltaY > 0) {
                    //collisionSide = CollisionSide::Top;
                    massiv1[0] = true;
                } else {
                    //collisionSide = CollisionSide::Bottom;
                    massiv1[2] = true;
                }
            }


        }

    }
    blinky->stopMovingBlinky(elapsedTime, massiv1);
    sf::FloatRect clydeBounds = clyde->getBounds();

    for (auto cell: cells) {
        sf::FloatRect cellBounds = cell->getBounds();
        sf::Vector2f clydeCenter = sf::Vector2f(clydeBounds.left, clydeBounds.top) +
                                    0.5f * sf::Vector2f(clydeBounds.width, clydeBounds.height);
        sf::Vector2f cellCenter = sf::Vector2f(cellBounds.left, cellBounds.top) +
                                  0.5f * sf::Vector2f(cellBounds.width, cellBounds.height);

        sf::Vector2f delta = clydeCenter - cellCenter;

        float deltaX = delta.x;
        float deltaY = delta.y;

        //CollisionSide collisionSide = CollisionSide::None;

        if (std::abs(deltaX) < 18 && std::abs(deltaY) < 18) {
            if (std::abs(deltaX) > std::abs(deltaY)) {//std::abs(deltaY)
                if (deltaX > 0) {
                    //collisionSide = CollisionSide::Left;
                    massiv2[3] = true;

                } else {
                    //collisionSide = CollisionSide::Right;
                    massiv2[1] = true;
                }
            } else if (std::abs(deltaX) < std::abs(deltaY)) {
                if (deltaY > 0) {
                    //collisionSide = CollisionSide::Top;
                    massiv2[0] = true;
                } else {
                    //collisionSide = CollisionSide::Bottom;
                    massiv2[2] = true;
                }
            }


        }

    }
    clyde->stopMovingClyde(elapsedTime, massiv2);

    sf::FloatRect inkyBounds = inky->getBounds();

    for (auto cell: cells) {
        sf::FloatRect cellBounds = cell->getBounds();
        sf::Vector2f inkyCenter = sf::Vector2f(inkyBounds.left, inkyBounds.top) +
                                   0.5f * sf::Vector2f(inkyBounds.width, inkyBounds.height);
        sf::Vector2f cellCenter = sf::Vector2f(cellBounds.left, cellBounds.top) +
                                  0.5f * sf::Vector2f(cellBounds.width, cellBounds.height);

        sf::Vector2f delta = inkyCenter - cellCenter;

        float deltaX = delta.x;
        float deltaY = delta.y;

        //CollisionSide collisionSide = CollisionSide::None;

        if (std::abs(deltaX) < 18 && std::abs(deltaY) < 18) {
            if (std::abs(deltaX) > std::abs(deltaY)) {//std::abs(deltaY)
                if (deltaX > 0) {
                    //collisionSide = CollisionSide::Left;
                    massiv3[3] = true;

                } else {
                    //collisionSide = CollisionSide::Right;
                    massiv3[1] = true;
                }
            } else if (std::abs(deltaX) < std::abs(deltaY)) {
                if (deltaY > 0) {
                    //collisionSide = CollisionSide::Top;
                    massiv3[0] = true;
                } else {
                    //collisionSide = CollisionSide::Bottom;
                    massiv3[2] = true;
                }
            }


        }

    }
    inky->stopMovingInky(elapsedTime, massiv3);

    sf::FloatRect pinkyBounds = pinky->getBounds();

    for (auto cell: cells) {
        sf::FloatRect cellBounds = cell->getBounds();
        sf::Vector2f pinkyCenter = sf::Vector2f(pinkyBounds.left, pinkyBounds.top) +
                                   0.5f * sf::Vector2f(pinkyBounds.width, pinkyBounds.height);
        sf::Vector2f cellCenter = sf::Vector2f(cellBounds.left, cellBounds.top) +
                                  0.5f * sf::Vector2f(cellBounds.width, cellBounds.height);

        sf::Vector2f delta = pinkyCenter - cellCenter;

        float deltaX = delta.x;
        float deltaY = delta.y;

        //CollisionSide collisionSide = CollisionSide::None;

        if (std::abs(deltaX) < 18 && std::abs(deltaY) < 18) {
            if (std::abs(deltaX) > std::abs(deltaY)) {//std::abs(deltaY)
                if (deltaX > 0) {
                    //collisionSide = CollisionSide::Left;
                    massiv4[3] = true;

                } else {
                    //collisionSide = CollisionSide::Right;
                    massiv4[1] = true;
                }
            } else if (std::abs(deltaX) < std::abs(deltaY)) {
                if (deltaY > 0) {
                    //collisionSide = CollisionSide::Top;
                    massiv4[0] = true;
                } else {
                    //collisionSide = CollisionSide::Bottom;
                    massiv4[2] = true;
                }
            }


        }

    }
    pinky->stopMovingPinky(elapsedTime, massiv4);

}





void Game::render(sf::RenderWindow& window) const
{
    //sf::FloatRect pinkyBounds = pinky->getBounds();
    //sf::FloatRect inkyBounds = inky->getBounds();
    //sf::FloatRect clydeBounds = clyde->getBounds();
    //sf::FloatRect blinkyBounds = blinky->getBounds();

    // Отрисовка стенок
    for (auto cell : cells)
    {
        cell->render(window);
    }
    // Отрисовка остальных объектов
    //for (const auto& object : objects)
    //{
      //  object->render(window);
    //}

    // Отрисовка точек
    for (auto point : points)
    {
        point->render(window);
    }

    for (auto super_point : super_points)
    {
        super_point->render(window);
    }

    blinky->render(window);
    clyde->render(window);
    inky->render(window);
    pinky->render(window);
    pacman->render(window);
    // Отрисуйте другие объекты, если необходимо
}

Game::~Game()
{
    delete pacman;
    delete blinky;

    for (auto entity : objects)
    {
        delete entity;

    }

    /*for (auto inky : inkys)
    {
        delete ghost;
    }*/
    for (auto point : points)
    {
        delete point;
    }
    for (auto cell : cells)
    {
        delete cell;
    }

}


