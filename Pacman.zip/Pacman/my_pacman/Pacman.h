#pragma once
#include "Entity.h"

static const sf::Color PACKMAN_COLOR = sf::Color(255, 216, 0);
static const float PACKMAN_SPEED = 80.f; // pixels per second.
static const int PACKMAN_RADIUS = 7; // pixels
enum class CollisionSide
{
    None,
    Left,
    Right,
    Top,
    Bottom
};
class Pacman: public MovingEntity
{
private:
    bool isMoving;
    bool isSuperPacman;
    sf::Clock timer;
public:
	Pacman(int xPos, int yPos) {
        isMoving = true;
        isSuperPacman = false;
        //direction = Direction::NONE;
		shape.setRadius(PACKMAN_RADIUS);
		shape.setFillColor(PACKMAN_COLOR);
		shape.setPosition(sf::Vector2f(xPos, yPos));
	}
    void eatSuperPellet() {
        isSuperPacman = true;
        timer.restart();
    }

    void stopMoving(float elapsedTime, std::vector<bool>& massiv)
    {
        isMoving = false;
        const float step = PACKMAN_SPEED * elapsedTime;
        sf::Vector2f antimovement(0.f, 0.f);
        // Обработка остановки движения в зависимости от стороны столкновения

        if(massiv[0]){
            antimovement.y += step;
        }
        if(massiv[1]){
            antimovement.x -= step;
        }
        if(massiv[2]){
            antimovement.y -= step;
        }
        if(massiv[3]){
            antimovement.x += step;
        }

        shape.move(antimovement);
    }

	void updatePacmanDirection(std::vector<bool>& massiv) {
        isMoving = true;
        //direction = Direction::NONE;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && !massiv[0])
        {
            direction = Direction::UP;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && !massiv[2])
        {
            direction = Direction::DOWN;

        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && !massiv[3])
        {
            direction = Direction::LEFT;

        }
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && !massiv[1])
        {
            direction = Direction::RIGHT;
        }


	}


    void update(float elapsedTime, std::vector<std::string> map, std::vector<bool>& massiv) {
        //const float step = PACKMAN_SPEED * elapsedTime;
        const float step = (isSuperPacman ? PACKMAN_SPEED * 1.5f : PACKMAN_SPEED) * elapsedTime;
        // Проверка времени и сброс состояния супер-пакмана
        if (isSuperPacman && timer.getElapsedTime().asSeconds() >= 5.f) {
            isSuperPacman = false;
        }

        updatePacmanDirection(massiv);
        if (!isMoving) {
            return;
        }


        sf::Vector2f movement(0.f, 0.f);
        switch (direction) {
            case Direction::UP:
                movement.y -= step;
                break;
            case Direction::DOWN:
                movement.y += step;
                break;
            case Direction::LEFT:
                movement.x -= step;
                break;
            case Direction::RIGHT:
                movement.x += step;
                break;

        }

        shape.move(movement);

    }

};