#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System/Clock.hpp>

enum struct Direction
{
    NONE,
    UP,
    DOWN,
    LEFT,
    RIGHT
};

class Entity
{
protected:
    int xPos;
    int yPos;
    int size;

public:

    virtual ~Entity() {}
    virtual void render(sf::RenderWindow& window) = 0;
    virtual void update(float elapsedTime) {}
    virtual sf::FloatRect getBounds()  = 0;
};

class StaticEntity : public Entity
{
protected:
    sf::FloatRect bounds;
    sf::RectangleShape shape;

public:
    sf::FloatRect getBounds() override {
        return shape.getGlobalBounds();
    }
    StaticEntity()
    {
        shape.setOutlineThickness(1);
        shape.setOutlineColor(sf::Color::Black);
    }

    void render(sf::RenderWindow& window) override
    {
        window.draw(shape);
    }
};

class PacGum : public StaticEntity
{
public:
    sf::Vector2f getpos(){return sf::Vector2f(xPos, yPos);}
    int getsize(){return size;}
    PacGum(int x, int y, int s)
    {
        xPos = x;
        yPos = y;
        size = s;
    }
    void render(sf::RenderWindow& window) override
    {

        sf::CircleShape shape(size / 2); // Создаем круглую форму
        shape.setFillColor(sf::Color(255, 183, 174));
        shape.setPosition(sf::Vector2f(xPos + (size / 2)-3, yPos +(size / 2)-3)); // Устанавливаем позицию по центру
        shape.setOrigin(sf::Vector2f(size / 2, size / 2)); // Устанавливаем центр вращения по центру
        window.draw(shape);
    }
};

class SuperPacGum : public StaticEntity
{
public:
    sf::Vector2f getpos1(){return sf::Vector2f(xPos, yPos);}
    int getsize1(){return size;}
    SuperPacGum(int x, int y, int s)
    {
        xPos = x;
        yPos = y;
        size = s;
    }
    void render(sf::RenderWindow& window) override
    {
        sf::CircleShape shape(size / 2); // Создаем круглую форму
        shape.setFillColor(sf::Color(255, 183, 174));
        shape.setPosition(sf::Vector2f(xPos + (size / 2)-3, yPos +(size / 2)-3)); // Устанавливаем позицию по центру
        shape.setOrigin(sf::Vector2f(size / 2, size / 2)); // Устанавливаем центр вращения по центру
        window.draw(shape);
    }
};

class MovingEntity : public Entity
{
protected:
    int speed;
    int score;

    sf::Vector2i speedVec;
    Direction direction;
    sf::CircleShape shape;

public:
    void update(float elapsedTime) override {}
    void render(sf::RenderWindow& window) override
    {
        window.draw(shape);
    }
    sf::FloatRect getBounds() override
    {
        return shape.getGlobalBounds();
    }
    // setters, getters, etc.
};
