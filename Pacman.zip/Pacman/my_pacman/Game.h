#pragma once

#include <vector>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include "Pacman.h"
#include "Entity.h"
#include "Ghost.h"
#include "Cell.h"
#include <SFML/Audio.hpp>

const int WINDOW_WIGHT = 21;
const int WINDOW_HEIGHT = 21;
const float CELL_SIZE = 20;
const float PacGum_SIZE = 4;
const float SuperPacGum_SIZE = 6;




class Game
{
    int width;
    int height;
    int score = 0;
    bool isSuperPacman;
    std::vector<std::string> map;
    std::vector<Entity*> objects;
    //std::vector<Ghost*> ghosts;
    std::vector<Cell*> cells;
    std::vector<PacGum*> points;
    std::vector<SuperPacGum*> super_points;
    Blinky* blinky;
    Clyde* clyde;
    Inky* inky;
    Pinky* pinky;
    Pacman* pacman;

public:
    Game();
    std::vector<Entity*> getEntities();
    std::vector<Cell*> getCells();
    Pacman* getPacman();
    Blinky* getBlinky();
    Clyde* getClyde();
    Inky* getInky();
    Pinky* getPinky();
    void updateGame(float elapsedTime);
    void checkCollisions(float elapsedTime, std::vector<bool>& massiv, std::vector<bool>& massiv1, std::vector<bool>& massiv2, std::vector<bool>& massiv3, std::vector<bool>& massiv4);// /////////////////////////////////////
    //void checkCollisionsGhost(float elapsedTime, std::vector<bool>& massiv1);
    void render(sf::RenderWindow& window) const;
    ~Game();
};
